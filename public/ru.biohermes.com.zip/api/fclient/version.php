<?php

/**
 * 客户端app版本号
 */

return '4.0';