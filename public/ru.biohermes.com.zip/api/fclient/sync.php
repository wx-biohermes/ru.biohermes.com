<?php

/**
 * 客户端通信配置
 */

return [
    'id' => '75',
    'sn' => 'PHPCMF6AAFD19FCF0B8',
    'name' => 'BioHermes',
    'domain' => 'https://ru.biohermes.com/',
    'endtime' => '1846684800',
    'status' => '2',
    'close_url' => '',
    'pay_url' => '',
    'server_url' => 'https://www.wsw88.cn/',
];